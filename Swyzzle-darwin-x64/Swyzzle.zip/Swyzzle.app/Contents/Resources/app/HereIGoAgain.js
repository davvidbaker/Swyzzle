const str = `I don't know where I'm going
But, I sure know where I've been
Hanging on the promises
In songs of yesterday
An' I've made up my mind,
I ain't wasting no more time
But, here I go again
Here I go again

Tho' I keep searching for an answer,
I never seem to find what I'm looking for
Oh Lord, I pray
You give me strength to carry on,
'Cause I know what it means
To walk along the lonely street of dreams

An' here I go again on my own
Goin' down the only road I've ever known,
Like a hobo I was born to walk alone
An' I've made up my mind
I ain't wasting no more time

I'm just another heart in need of rescue,
Waiting on love's sweet charity
An' I'm gonna hold on
For the rest of my days,
'Cause I know what it means
To walk along the lonely street of dreams

An' here I go again on my own
Goin' down the only road I've ever known,
Like a hobo I was born to walk alone
An' I've made up my mind
I ain't wasting no more time

But, here I go again,
Here I go again,
Here I go again,
Here I go...

'Cause I know what it means
To walk along the lonely street of dreams

Here I go again on my own
Going down the only road I've ever known
Like a drifter I was born to walk alone
And I've made up my mind
I ain't wasting no more time

Here I go again on my own
Going down the only road I've ever known
Like a drifter I was born to walk alone
And I've made up my mind
I ain't wasting no more time

'Cause I know what it means
To walk along the lonely street of dreams

Here I go again on my own
Going down the only road I've ever known
Like a drifter I was born to walk alone
And I've made up my mind
I ain't wasting no more time`;

const arr = str.split(/\s/);

module.exports = arr;